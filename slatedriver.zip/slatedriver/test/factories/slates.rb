FactoryGirl.define do
  factory :slate do
    name "MyString"
    election_cycle "MyString"

    
  end
end
