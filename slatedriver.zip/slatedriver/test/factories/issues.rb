FactoryGirl.define do
  factory :issue do
    slate
    namechoices "MyString"
    recommendation "MyString"
  end
end
