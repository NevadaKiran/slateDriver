(function(){
  angular
    .module('slatedriver', ['ui.router', 'Devise', 'templates'])
}())
